package com.example.borisho.guessingfungame;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private Questions theQuestions = new Questions();
    private Button answer1, answer2, answer3,answer4;
    private ImageView img;
    private TextView mScore;
    private String aAnswer = null;
    private int gameScore = 0;
    private int questionNumber=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        img = (ImageView)findViewById(R.id.question_image);
        answer1 = (Button)findViewById(R.id.answer1_button);
        answer2 = (Button)findViewById(R.id.answer2_button);
        answer3 = (Button)findViewById(R.id.answer3_button);
        answer4 = (Button)findViewById(R.id.answer4_button);
        mScore = (TextView)findViewById(R.id.score);
         updateQuestion();
        updateScore(gameScore);

        answer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(answer1.getText().toString().toUpperCase().equals(aAnswer.toUpperCase()) ){
                    gameScore++;
                    questionNumber++;
                    updateScore(gameScore);
                    updateQuestion();
                    Toast.makeText(MainActivity.this,"Correct", Toast.LENGTH_SHORT).show();
                 }
                 else{
                    Toast.makeText(MainActivity.this,"Wrong", Toast.LENGTH_SHORT).show();
                    updateQuestion();
                }

            }
        });
        answer2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(answer2.getText().toString().toUpperCase().equals(aAnswer.toUpperCase()) ){
                    gameScore++;
                    updateScore(gameScore);
                    questionNumber++;
                    updateQuestion();
                    Toast.makeText(MainActivity.this,"Correct", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(MainActivity.this,"Wrong", Toast.LENGTH_SHORT).show();
                    updateQuestion();
                }
            }
        });
        answer3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(answer3.getText().toString().toUpperCase().equals(aAnswer.toUpperCase()) ){
                    gameScore = gameScore+1;
                    updateScore(gameScore);
                    questionNumber++;
                    updateQuestion();
                    Toast.makeText(MainActivity.this,"Correct", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this,"Wrong", Toast.LENGTH_SHORT).show();
                    updateQuestion();
                }
            }
        });
        answer4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(answer4.getText() .toString().toUpperCase().equals(aAnswer.toUpperCase()) ){
                    gameScore = gameScore+1;
                    questionNumber++;
                    updateQuestion();
                    Toast.makeText(MainActivity.this,"Correct", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(MainActivity.this,"Wrong", Toast.LENGTH_SHORT).show();
                    updateQuestion();
                }
            }
        });


    }
    private void updateQuestion(){
        if(questionNumber == 10){
            questionNumber = 0;

        }
        switch (questionNumber){
            case 0:
                img.setImageResource(R.drawable.civilization);
                answer1.setText(theQuestions.getChoice1(questionNumber));
                answer2.setText(theQuestions.getChoice2(questionNumber));
                answer3.setText(theQuestions.getChoice3(questionNumber));
                answer4.setText(theQuestions.getChoice4(questionNumber));
                aAnswer = theQuestions.getAnswers(questionNumber);
                break;
            case 1:
                img.setImageResource(R.drawable.doom);
                answer1.setText(theQuestions.getChoice1(questionNumber));
                answer2.setText(theQuestions.getChoice2(questionNumber));
                answer3.setText(theQuestions.getChoice3(questionNumber));
                answer4.setText(theQuestions.getChoice4(questionNumber));
                aAnswer = theQuestions.getAnswers(questionNumber);
                break;
            case 2:
                img.setImageResource(R.drawable.elite);
                answer1.setText(theQuestions.getChoice1(questionNumber));
                answer2.setText(theQuestions.getChoice2(questionNumber));
                answer3.setText(theQuestions.getChoice3(questionNumber));
                answer4.setText(theQuestions.getChoice4(questionNumber));
                aAnswer = theQuestions.getAnswers(questionNumber);
                break;
            case 3:
                img.setImageResource(R.drawable.halflife);
                answer1.setText(theQuestions.getChoice1(questionNumber));
                answer2.setText(theQuestions.getChoice2(questionNumber));
                answer3.setText(theQuestions.getChoice3(questionNumber));
                answer4.setText(theQuestions.getChoice4(questionNumber));
                aAnswer = theQuestions.getAnswers(questionNumber);
                break;
            case 4:
                img.setImageResource(R.drawable.minesweeper);
                answer1.setText(theQuestions.getChoice1(questionNumber));
                answer2.setText(theQuestions.getChoice2(questionNumber));
                answer3.setText(theQuestions.getChoice3(questionNumber));
                answer4.setText(theQuestions.getChoice4(questionNumber));
                aAnswer = theQuestions.getAnswers(questionNumber);
                break;
            case 5:
                img.setImageResource(R.drawable.neverwinternights);
                answer1.setText(theQuestions.getChoice1(questionNumber));
                answer2.setText(theQuestions.getChoice2(questionNumber));
                answer3.setText(theQuestions.getChoice3(questionNumber));
                answer4.setText(theQuestions.getChoice4(questionNumber));
                aAnswer = theQuestions.getAnswers(questionNumber);

                break;
            case 6:
                img.setImageResource(R.drawable.spacewar);
                answer1.setText(theQuestions.getChoice1(questionNumber));
                answer2.setText(theQuestions.getChoice2(questionNumber));
                answer3.setText(theQuestions.getChoice3(questionNumber));
                answer4.setText(theQuestions.getChoice4(questionNumber));
                aAnswer = theQuestions.getAnswers(questionNumber);

                break;
            case 7:
                img.setImageResource(R.drawable.tetris);
                answer1.setText(theQuestions.getChoice1(questionNumber));
                answer2.setText(theQuestions.getChoice2(questionNumber));
                answer3.setText(theQuestions.getChoice3(questionNumber));
                answer4.setText(theQuestions.getChoice4(questionNumber));
                aAnswer = theQuestions.getAnswers(questionNumber);

                break;
            case 8:
                img.setImageResource(R.drawable.thesims);
                answer1.setText(theQuestions.getChoice1(questionNumber));
                answer2.setText(theQuestions.getChoice2(questionNumber));
                answer3.setText(theQuestions.getChoice3(questionNumber));
                answer4.setText(theQuestions.getChoice4(questionNumber));
                aAnswer = theQuestions.getAnswers(questionNumber);

                break;
            case 9:
                img.setImageResource(R.drawable.worldofwarcraft);
                answer1.setText(theQuestions.getChoice1(questionNumber));
                answer2.setText(theQuestions.getChoice2(questionNumber));
                answer3.setText(theQuestions.getChoice3(questionNumber));
                answer4.setText(theQuestions.getChoice4(questionNumber));
                aAnswer = theQuestions.getAnswers(questionNumber);
                break;
        }
    }
    private void updateScore(int o){
        String ok = Integer.toString(o);
        mScore.setText(ok);
    }
}
