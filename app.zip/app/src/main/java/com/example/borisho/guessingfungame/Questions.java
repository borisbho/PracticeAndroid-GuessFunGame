package com.example.borisho.guessingfungame;

import android.widget.ImageView;

public class Questions {
    private String[] allQuestions ={
            "civilization",
            "doom",
            "elite",
            "halflife",
            "minesweeper",
            "neverwinternights",
            "spacewar",
            "tetris",
            "thesims",
            "worldofwarcraft"
    };

    private String mChoices[][]={
            {"Civilization", "Doom", "Elite", "Minesweeper"},
            {"Half Life", "Minesweeper", "Doom", "The Sims"},
            {"Civilization", "Elite", "Never Winter Nights", "World Of Warcraft"},
            {"SpaceWar", "Never Winter Nights", "Half Life","Tetris"},
            {"Minesweeper", "Never Winter Nights", "The Sims", "Tetris"},
            {"Never Winter Nights", "SpaceWar", "The Sims", "Civilizatiohn"},
            {"Civilization", "Never Winter Nights", "SpaceWar", "Tetris"},
            {"Tetris", "The Sims", "Doom", "Elite"},
            {"Half Life", "The Sims", "World Of Warcraft", "Elite"},
            {"World Of Warcraft", "Elite", "Doom", "Civilization"}
    };
    private String mCorrectAnswers[] = {"Civilization", "Doom", "Elite","Half Life","Minesweeper","Never Winter Nights",
    "SpaceWar","Tetris","The Sims", "World Of Warcraft"};

    public String GetQuestion(int a){
        String Question = allQuestions[a];
        return Question;
    }
    public String getChoice1(int a){
        String Choice0 = mChoices[a][0];
        return Choice0;
    }
    public String getChoice2(int a){
        String Choice1 = mChoices[a][1];
        return Choice1;
    }
    public String getChoice3(int a){
        String Choice2 = mChoices[a][2];
        return Choice2;
    }
    public String getChoice4(int a){
        String Choice3 = mChoices[a][3];
        return Choice3;
    }
    public String getAnswers(int a){
        String answer = mCorrectAnswers[a];
        return answer;
    }
}
